package com.example.macstudent.sqlitedatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.macstudent.sqlitedatabase.db.Model.Contact;
import com.example.macstudent.sqlitedatabase.db.helper.DBContact;

import java.util.ArrayList;
import java.util.List;

public class ContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBContact dbContact = new DBContact(this);


        Log.d("Insert: ", "Inserting ..");

        dbContact.addContact(new Contact("Ravi", "9100000000"));
        dbContact.addContact(new Contact("Srinivas", "9199999999"));
        dbContact.addContact(new Contact("Tommy", "9522222222"));
        dbContact.addContact(new Contact("Karthik", "9533333333"));


        // Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<Contact> contacts = dbContact.getAllContacts();

        List<DBContact> contactList = new ArrayList<>();

        for (Contact cn : contacts) {
            String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() + " ,Phone: " + cn.getPhoneNumber();
            // Writing Contacts to log

            Log.d("Name: ", log);

        }
    }
}
