package com.example.macstudent.sqlitedatabase.db.Model;

/**
 * Created by macstudent on 2017-11-30.
 */

public class Person {


    // Contacts Table Columns names
    static final String KEY_ID = "id";
    static final String KEY_NAME = "name";

    public Person() {

    }

    public Person(String key_id, String key_name) {

    }

    public static String getKeyId() {
        return KEY_ID;
    }

    public static String getKeyName() {
        return KEY_NAME;
    }



}
