package com.example.macstudent.sqlitedatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ListView extends AppCompatActivity {


    ListView lstcntct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);



    }
}
