package com.example.macstudent.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Third extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
    }
}
