package com.example.macstudent.myapplication;

import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {


    Button btn;
    RadioGroup rbg;
    CheckBox cb1, cb2, cb3;
    ToggleButton tb;
    SeekBar sb;
    ProgressBar pbTest;
    RatingBar rbTest;
    Spinner spTest;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn = (Button)findViewById(R.id.btnMove);
        rbg = (RadioGroup)findViewById(R.id.rbGroup);
        cb1 = (CheckBox) findViewById(R.id.checkBoxFirst);
        cb2 = (CheckBox) findViewById(R.id.checkBoxSecond);
        cb3 = (CheckBox) findViewById(R.id.checkBoxThird);
        tb = (ToggleButton) findViewById(R.id.tbState);
        sb = (SeekBar)findViewById(R.id.sbTest);
        pbTest = (ProgressBar) findViewById(R.id.pbTest);
        rbTest = (RatingBar) findViewById(R.id.rbTest);
        spTest = (Spinner)findViewById(R.id.spTest);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(getApplicationContext(),Second.class);

                intent.putExtra("name", "Lambton College");
                intent.putExtra("id", 1);

                startActivity(intent);

            }
        });


        rbg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {


                if(i == R.id.rbFirst) {
                    Toast.makeText(MainActivity.this, "First", Toast.LENGTH_SHORT).show();
                }else if(i == R.id.rbSecond){

                    Toast.makeText(MainActivity.this, "Second", Toast.LENGTH_SHORT).show();

                }
                else if(i == R.id.rbThird){

                    Toast.makeText(MainActivity.this, "Third", Toast.LENGTH_SHORT).show();

                }

            }
        });


        cb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {


                Toast.makeText(MainActivity.this, "First checkBox", Toast.LENGTH_SHORT).show();
                if(cb2.isChecked())
                cb2.setChecked(false);

                if(cb3.isChecked())
                cb3.setChecked(false);

            }
        });

        cb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {


                Toast.makeText(MainActivity.this, "Second checkBox", Toast.LENGTH_SHORT).show();
                if(cb1.isChecked())
                cb1.setChecked(false);
                if(cb3.isChecked())
                cb3.setChecked(false);

            }
        });

        cb3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {


                Toast.makeText(MainActivity.this, "Third checkBox", Toast.LENGTH_SHORT).show();
                if(cb2.isChecked())
                cb2.setChecked(false);
                if(cb1.isChecked())
                cb1.setChecked(false);

            }
        });


        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {


                if(tb.isChecked()){
                    Toast.makeText(MainActivity.this,"On", Toast.LENGTH_SHORT).show();
                }else{

                    Toast.makeText(MainActivity.this,"Off", Toast.LENGTH_SHORT).show();

                }

            }
        });

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                Toast.makeText(MainActivity.this,"Value : " + i, Toast.LENGTH_SHORT).show();


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        rbTest.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {


                Toast.makeText(MainActivity.this,"Rating : " + v, Toast.LENGTH_SHORT).show();

            }
        });


        String[] option = new String[]{"Easy","Medium","Hard"};
        ArrayList<String> list = new ArrayList<>(Arrays.asList(option));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_single_choice,list);
      //  dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spTest.setAdapter(dataAdapter);
        list.add("Extar Hard");
        dataAdapter.notifyDataSetChanged();

      spTest.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
              Toast.makeText(MainActivity.this,"Rating : " + String.valueOf(spTest.getSelectedItem()), Toast.LENGTH_SHORT).show();
          }

          @Override
          public void onNothingSelected(AdapterView<?> adapterView) {

          }
      });


    }
}
