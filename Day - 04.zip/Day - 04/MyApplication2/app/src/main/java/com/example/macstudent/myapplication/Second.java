package com.example.macstudent.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Second extends AppCompatActivity {


    TextView txtTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtTitle = (TextView)findViewById(R.id.txtTitle);

        Bundle b = getIntent().getExtras();

        txtTitle.setText(b.getString("name"));


        if(b != null){

            String title = "No Title";
            int id ;

            if(b.containsKey("name")){

                title = b.getString("name");

            }

            id = b.getInt("id");
            txtTitle.setText(id + " " + title);

        }
        else {

            txtTitle.setText("No Data");

        }

    }
}
