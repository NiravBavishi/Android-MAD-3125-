package com.example.macstudent.c0717705_cricketplayerrank;

import android.database.Cursor;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class EnterDetailActivity extends AppCompatActivity {


    DatabaseHelper mydb;

    Spinner spCountry;
    EditText etName, etBirthDate, etNoOfTestMatch, etNoOf1DayMatch, etCatch, etRun, etWicket, etStumping;
    Button btnSubmit, btnView;
    RadioGroup rbGender, rbCategory;

    String Name, BirthDate, gender, country, category;
    int NoOfTestMatch, NoOf1DayMatch, Catch, Run, Wicket, Stumping, total;


    public int calculatePoints(int NoOfTestMatch, int NoOf1DayMatch, int Catch, int Run, int Wicket, int Stumping){

        return (NoOfTestMatch * 5) + (NoOf1DayMatch * 2) + ( Catch * 3)  + Run + (Wicket * 5) + (Stumping * 3);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_detail);

        setTitle("Enter Detail");

        spCountry = (Spinner)findViewById(R.id.spCountry);
        etName = (EditText)findViewById(R.id.etName);
        etBirthDate = (EditText)findViewById(R.id.etBirthDate);
        etNoOfTestMatch = (EditText)findViewById(R.id.etNoOfTestMatch);
        etNoOf1DayMatch = (EditText)findViewById(R.id.etNoOf1DayMatch);
        etCatch = (EditText)findViewById(R.id.etCatch);
        etRun = (EditText)findViewById(R.id.etRun);
        etWicket = (EditText)findViewById(R.id.etWicket);
        etStumping = (EditText)findViewById(R.id.etStumping);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        rbGender =  (RadioGroup) findViewById(R.id.rbGender);
        rbCategory = (RadioGroup) findViewById(R.id.rbCategory);
        btnView = (Button) findViewById(R.id.btnView);


        //Spinner
        String[] option = new String[]{"India","Brazil","Canada","England"};
        ArrayList<String> list = new ArrayList<>(Arrays.asList(option));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_single_choice,list);
        //  dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spCountry.setAdapter(dataAdapter);

        //// Spinner

        mydb = new DatabaseHelper(this);


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                // get Data From Element



                Name = etName.getText().toString();
                BirthDate = etBirthDate.getText().toString();
                NoOfTestMatch = Integer.valueOf(etNoOfTestMatch.getText().toString());
                NoOf1DayMatch = Integer.valueOf(etNoOf1DayMatch.getText().toString());
                Catch = Integer.valueOf(etCatch.getText().toString());
                Run = Integer.valueOf(etRun.getText().toString());
                Wicket= Integer.valueOf(etWicket.getText().toString());
                Stumping= Integer.valueOf(etStumping.getText().toString());

                rbGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {

                        if(i == R.id.rbMale) {

                            gender = "Male";

                        }else if(i == R.id.rbFemale){

                            gender = "Female";

                        }
                        else if(i == R.id.rbOther){

                            gender = "Other";

                        }

                    }
                });

                rbCategory.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {

                        if(i == R.id.rbBetsman) {

                            category = "Betsman";

                        }else if(i == R.id.rbBowler){

                            category = "Bowler";

                        }
                        else if(i == R.id.rbWicketKeeper){

                            category = "Wicket Keeper";

                        }

                    }
                });

                spCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                        country = String.valueOf(spCountry.getSelectedItem());

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });

                total = calculatePoints(NoOfTestMatch, NoOf1DayMatch, Catch, Run, Wicket, Stumping);




                //// Get Data From Element



                boolean isInserted =  mydb.insertData(Name,gender,BirthDate, category, country, String.valueOf(NoOfTestMatch), String.valueOf(NoOf1DayMatch), String.valueOf(Catch),String.valueOf(Run),String.valueOf(Wicket),String.valueOf(Stumping),String.valueOf(total));

                if(isInserted){

                    Toast.makeText(EnterDetailActivity.this, "Data Inserted Successfully", Toast.LENGTH_SHORT).show();

                }else {

                    Toast.makeText(EnterDetailActivity.this, "Data Insertion Fail !", Toast.LENGTH_SHORT).show();

                }

            }
        });

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Cursor res = mydb.getAllData();

                if(res.getCount() == 0){

                    Toast.makeText(EnterDetailActivity.this, "No Data", Toast.LENGTH_SHORT).show();

                }else{

                    Toast.makeText(EnterDetailActivity.this, "Data is There", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }



}
