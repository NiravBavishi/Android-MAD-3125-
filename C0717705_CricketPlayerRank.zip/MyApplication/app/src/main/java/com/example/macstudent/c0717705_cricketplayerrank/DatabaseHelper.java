package com.example.macstudent.c0717705_cricketplayerrank;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by macstudent on 2017-12-01.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "CricketPlayer.db";
    public static final String TABLE_NAME = "PlayerData";
    public static final String COL_0 = "ID";
    public static final String COL_1 = "NAME";
    public static final String COL_2 = "GENDER";
    public static final String COL_3 = "BIRTHDATE";
    public static final String COL_4 = "CATEGORY";
    public static final String COL_5 = "COUNTRY";
    public static final String COL_6 = "TESTMATCH";
    public static final String COL_7 = "ONEDAY";
    public static final String COL_8 = "CATCH";
    public static final String COL_9 = "RUN";
    public static final String COL_10 = "WICKET";
    public static final String COL_11 = "STUMPING";
    public static final String COL_12 = "TOTAL";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,NAME TEXT,GENDER TEXT,BIRTHDATE TEXT,CATEGORY TEXT,COUNTRY TEXT,TESTMATCH TEXT,ONEDAY TEXT,CATCH TEXT,RUN TEXT,WICKET TEXT,STUMPING TEXT,TOTAL TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

//    public boolean insertData(String name,String surname,String marks) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put(COL_2,name);
//        contentValues.put(COL_3,surname);
//        contentValues.put(COL_4,marks);
//        long result = db.insert(TABLE_NAME,null ,contentValues);
//        if(result == -1)
//            return false;
//        else
//            return true;
//    }


    public boolean insertData(String name, String gender, String birthdate, String category, String country, String testmatch, String oneday, String Catch, String run, String wicket, String stumping, String total){


        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL_1,name);
        cv.put(COL_2,gender);
        cv.put(COL_3,birthdate);
        cv.put(COL_4,category);
        cv.put(COL_5,country);
        cv.put(COL_6,testmatch);
        cv.put(COL_7,oneday);
        cv.put(COL_8,Catch);
        cv.put(COL_9,run);
        cv.put(COL_10,wicket);
        cv.put(COL_11,stumping);
        cv.put(COL_12,total);

        long result = db.insert(TABLE_NAME,null,cv);

        if (result == -1){

            return false;

        }else{

            return true;

        }

    }


    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

}