package com.example.macstudent.c0717705_cricketplayerrank;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {


    public static final String EMAIL = "niravbavishi007@gmail.com";
    public static final String PASSWORD = "Nirav@33";

    EditText etEmail, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        setTitle("Login");

        etEmail = (EditText)findViewById(R.id.etEmail);
        etPassword = (EditText)findViewById(R.id.etPassword);
        btnLogin = (Button)findViewById(R.id.btnLogin);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(EMAIL.equals(etEmail.getText().toString()) && PASSWORD.equals(etPassword.getText().toString())){

                    Intent intent = new Intent(LoginActivity.this,EnterDetailActivity.class);
                    startActivity(intent);
                    finish();

                }else{

                    Toast.makeText(LoginActivity.this, "Enter Valid User Name And Password", Toast.LENGTH_LONG).show();

                }


            }
        });

    }
}
