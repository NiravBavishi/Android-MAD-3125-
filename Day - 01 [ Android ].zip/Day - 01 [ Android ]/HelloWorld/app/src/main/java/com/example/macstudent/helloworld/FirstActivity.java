package com.example.macstudent.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class FirstActivity extends AppCompatActivity {


    TextView txtTitel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtTitel = (TextView)findViewById(R.id.txtMessage);
        txtTitel.setText("Welcome To Android Programming");

        String s = txtTitel.getText().toString();

        Log.d("String",s);

    }
}
