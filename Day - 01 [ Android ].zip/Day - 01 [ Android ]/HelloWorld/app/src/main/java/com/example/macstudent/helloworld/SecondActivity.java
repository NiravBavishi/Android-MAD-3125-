package com.example.macstudent.helloworld;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SecondActivity extends Activity {


    EditText edtNo1, edtNo2;
    Button btnAdd, btnSub;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        edtNo1 = (EditText) findViewById(R.id.edtNumber1);
        edtNo2 = (EditText) findViewById(R.id.edtNumber2);

        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnSub = (Button) findViewById(R.id.btnSub);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int a,b,c;

                a = Integer.parseInt(edtNo1.getText().toString());
                b = Integer.parseInt(edtNo2.getText().toString());

                c = a + b;

                Toast.makeText(getApplicationContext(), "Addition : " + c , Toast.LENGTH_SHORT).show();

            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int a,b,c;

                a = Integer.parseInt(edtNo1.getText().toString());
                b = Integer.parseInt(edtNo2.getText().toString());

                c = a - b;

                Toast.makeText(getApplicationContext(), "Subtraction : " + c , Toast.LENGTH_SHORT).show();

            }
        });
    }
}
