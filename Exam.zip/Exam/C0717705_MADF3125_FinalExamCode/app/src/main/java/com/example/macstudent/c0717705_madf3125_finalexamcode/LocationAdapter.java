package com.example.macstudent.c0717705_madf3125_finalexamcode;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by macstudent on 2017-12-13.
 */

public class LocationAdapter extends BaseAdapter {



    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Location> dataSource;

    TextView tvTitle, tvLatitude, tvLongitude;

    public LocationAdapter(Context context, ArrayList<Location> items) {
        this.context = context;
        dataSource = items;
        inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        return dataSource.size();
    }


    @Override
    public Object getItem(int position) {
        return dataSource.get(position);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View rowView = inflater.inflate(R.layout.row_cell, parent, false);

        tvTitle =  (TextView) rowView.findViewById(R.id.tvTitle);
        tvLatitude =  (TextView) rowView.findViewById(R.id.tvLatitude);
        tvLongitude = (TextView) rowView.findViewById(R.id.tvLongitude);


        Location loc = (Location) getItem(position);


        tvTitle.setText(loc.getLocationTitle());
        tvLatitude.setText( String.valueOf(loc.getLatitude()));
        tvLongitude.setText( String.valueOf(loc.getLongitude()));




        return rowView;
    }
}


