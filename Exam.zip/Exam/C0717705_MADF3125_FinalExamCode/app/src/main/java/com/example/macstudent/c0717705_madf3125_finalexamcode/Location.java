package com.example.macstudent.c0717705_madf3125_finalexamcode;

import java.io.Serializable;

/**
 * Created by macstudent on 2017-12-13.
 */

public class Location implements Serializable {


    int locationId;
    String LocationTitle;
    double latitude,longitude;


    public Location() {

    }


    public Location(int locationId, String locationTitle, double latitude, double longitude) {
        this.locationId = locationId;
        LocationTitle = locationTitle;
        this.latitude = latitude;
        this.longitude = longitude;
    }


    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public String getLocationTitle() {
        return LocationTitle;
    }

    public void setLocationTitle(String locationTitle) {
        LocationTitle = locationTitle;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
