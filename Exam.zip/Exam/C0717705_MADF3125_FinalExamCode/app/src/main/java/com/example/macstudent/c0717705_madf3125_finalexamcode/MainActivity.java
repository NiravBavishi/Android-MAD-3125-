package com.example.macstudent.c0717705_madf3125_finalexamcode;

import android.content.Context;
import android.content.Intent;
import android.provider.Contacts;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    ListView lv;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        context=this;




        final ArrayList<Location> locationList = new ArrayList<>();

        Location l1, l2, l3, l4, l5, l6, l7, l8, l9, l10;

        l1 = new Location(1,"Home1", 20.232522, 23.3222482);
        l2 = new Location(2,"Home2", 20.232452, 23.7322242);
        l3 = new Location(3,"Home3", 20.232522, 23.3222482);
        l4 = new Location(4,"Home4", 20.232522, 23.3222482);
        l5 = new Location(5,"Home5", 20.232522, 23.3222482);
        l6 = new Location(6,"Home6", 20.232522, 23.3222482);
        l7 = new Location(7,"Home7", 20.232522, 23.3222482);
        l8 = new Location(8,"Home8", 20.232522, 23.3222482);
        l9 = new Location(9,"Home9", 20.232522, 23.3222482);
        l10 = new Location(10,"Home10", 20.232522, 23.3222482);


        locationList.add(l1);
        locationList.add(l2);
        locationList.add(l3);
        locationList.add(l4);
        locationList.add(l5);
        locationList.add(l6);
        locationList.add(l7);
        locationList.add(l8);
        locationList.add(l9);
        locationList.add(l10);


        lv=(ListView) findViewById(R.id.mapList);
        lv.setAdapter(new LocationAdapter(this,locationList));




        Location loc = (Location) lv.getSelectedItem();



        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Location loc =  locationList.get(i);

                Toast.makeText(context, "Location Title : " + loc.getLocationTitle(), Toast.LENGTH_SHORT).show();


                Intent intent = new Intent(MainActivity.this,MapsActivity.class);
                intent.putExtra("Location", (Serializable) loc);
                startActivity(intent);
                finish();




            }
        });


    }
}
